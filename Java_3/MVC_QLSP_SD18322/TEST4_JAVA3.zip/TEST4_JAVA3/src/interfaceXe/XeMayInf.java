/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaceXe;

import model.XeMay;

/**
 *
 * @author KHOA
 */
public interface XeMayInf {
    public int addXe(XeMay x);
    public int deleteXe(String ma);
    public int updateXe(XeMay x, String ma);
}
