create database quanLiThuVien_01
go
use quanLiThuVien_01
go
--tạo table
create table theLoai(
	maTL nchar(10) not null primary key,
	tenTl nvarchar(50) null
);
go 

create table sach(
	maSach nchar(10) not null primary key,
	tieuDe nvarchar(50),
	nhaXB nvarchar(50),
	tacGia nvarchar(50),
	soLuongBS int,
	giaTien float,
	ngayNhapKho date,
	viTri nvarchar(50),
	soTrang int,
	nhanXet nvarchar(50),
	maTL nchar(10) not null foreign key references theLoai(maTL)
);
go

create table tacGia(
	maTG nchar(10) not null primary key,
	hoTen nvarchar(50),
	butDanh nvarchar(50),
	diaChi nvarchar(50),
	sdt nchar(10)
);
go

create table sach_tacGia(
	maSach nchar(10) not null foreign key references sach(maSach),
	maTG nchar(10) not null foreign key references tacGia(maTG),
	primary key(maSach, maTG)
);
go

create table nganhHoc(
	maNganh nchar(10) not null primary key,
	tenNganh nvarchar(50)
);
go

create table lop(
	maLop nchar(10) not null primary key,
	tenLop nvarchar(50),
	maNganh nchar(10) not null foreign key references nganhHoc(maNganh)
);
go

create table sinhVien(
	maSV nchar(10) not null primary key,
	maLop nchar(10) not null foreign key references lop(maLop),
	hoTen nvarchar(50),
	diaChi nvarchar(50),
	email nvarchar(50),
	sdt nchar(10),
	ngaySinh date,
	ngayHetHan date
);
go

create table phieuMuon(
	maPhieu nchar(10) not null primary key,
	maSV nchar(10) not null foreign key references sinhVien(maSV),
	ngayMuon date
);
go

create table CTPhieuMuon(
	maSach nchar(10) not null foreign key references sach(maSach),
	maPhieu nchar(10) not null foreign key references phieuMuon(maPhieu),
	soLuong int,
	primary key(maSach, maPhieu)
);

--Nhập dữ liệu
select * from theLoai
insert into theLoai values ('TL01', N'Kinh tế'),
							('TL02', N'Công nghệ thông tin'),
							('TL03', N'Du lịch'),
							('TL04', N'Văn học'),
							('TL05', N'NGoại ngữ')

select * from sach 
insert into sach values ('MS01',N'con cò',N'con cò bé bé',N'who',100, 100, '09-22-1980', N'hà nội', 100, 'terrible','TL01'),
						('MS02',N'con cò',N'con cò bé bé',N'who',100, 100, '09-12-1980', N'hà nội', 100, 'terrible','TL01'),
						('MS03',N'con cò',N'con cò bé bé',N'who',100, 100, '09-10-1980', N'hà nội', 100, 'terrible','TL02'),
						('MS04',N'con cò',N'con cò bé bé',N'who',100, 100, '09-12-2000', N'hà nội', 100, 'terrible','TL01'),
						('MS05',N'con cò',N'con cò bé bé',N'who',100, 100, '09-12-1990', N'hà nội', 100, 'terrible','TL03')

select * from tacGia
insert into tacGia values ('TG01', N'Phạm Văn A', 'PVA', N'Mỹ Đình', '0814570032'),
							('TG02', N'Phạm Văn B', 'PVB', N'Mỹ Đình', '0814570032'),
							('TG03', N'Phạm Văn C', 'PVC', N'Mỹ Đình', '0814570032'),
							('TG04', N'Phạm Văn D', 'PVD', N'Mỹ Đình', '0814570032'),
							('TG05', N'Phạm Văn E', 'PVA2', N'Mỹ Đình', '0814570032')

select * from sach_tacGia
insert into sach_tacGia values ('MS01', 'TG02'),
								('MS01', 'TG04'),
								('MS02', 'TG02'),
								('MS03', 'TG02'),
								('MS01', 'TG01')

select * from nganhHoc
insert into nganhHoc values ('MN01', 'ten2'),
							('MN02', 'ten2'),
							('MN03', 'ten2'),
							('MN04', 'ten2'),
							('MN05', 'ten2')

select * from lop
insert into lop values ('L1', 'it18313', 'MN01'),
						('L2', 'it18313', 'MN01'),
						('L3', 'it18313', 'MN01'),
						('L4', 'it18313', 'MN01'),
						('L5', 'it18313', 'MN02')

select * from sinhVien
insert into sinhVien values ('ph001','L1', N'TRAN BUOI', N'TRAN DUY HUNG', 'phuong2004@G.MAIL', '0814570032', '07-29-2004', '3-2-2024'),
							('ph002','L1', N'TRAN BUOI', N'TRAN DUY HUNG', 'phuong2004@G.MAIL', '0814570032', '07-29-2004', '3-2-2024'),
							('ph003','L2', N'TRAN BUOI', N'TRAN DUY HUNG', 'phuong2004@G.MAIL', '0814570032', '07-29-2004', '3-2-2024'),
							('ph004','L1', N'TRAN BUOI', N'TRAN DUY HUNG', 'phuong2004@G.MAIL', '0814570032', '07-29-2004', '3-2-2024'),
							('ph005','L1', N'TRAN BUOI', N'TRAN DUY HUNG', 'phuong2004@G.MAIL', '0814570032', '07-29-2004', '3-2-2024')

select * from phieuMuon
insert into phieuMuon values ('P1', 'ph001', '10-02-2000'),
							('P2', 'ph001', '10-02-2000'),
							('P3', 'ph001', '10-02-2000'),
							('P4', 'ph001', '10-02-2000'),
							('P5', 'ph001', '10-02-2000')

select  * from CTPhieuMuon
insert into CTPhieuMuon values ('MS01', 'P1', 10),
								('MS02', 'P1', 10),
								('MS03', 'P1', 10),
								('MS02', 'P2', 10),
								('MS01', 'P4', 10)

--truy van
 /*6.1 Liệt kê tất cả thông tin của các đầu sách gồm tên sách, mã sách, giá tiền , tác giả
thuộc loại sách có mã “IT”.*/
select tieuDe, sach.maSach, giaTien, tacGia from sach
join sach_tacGia on sach.maSach = sach_tacGia.maSach
where maTL = 'TL'

/*6.2 Liệt kê các phiếu mượn gồm các thông tin mã phiếu mượn, mã sách , ngày mượn, mã
sinh viên có ngày mượn trong tháng 01/2017.*/
select * from phieuMuon
select * from CTPhieuMuon
select phieuMuon.maPhieu, maSach, ngayMuon, maSV from phieuMuon
join CTPhieuMuon on phieuMuon.maPhieu = CTPhieuMuon.maPhieu
where month(ngayMuon)=1 and year(ngayMuon)=1017

/*6.3 Liệt kê các phiếu mượn chưa trả sách cho thư viên theo thứ tự tăng dần của ngày
mượn sách.*/
ALTER TABLE PHIEUMUON
ADD TRANGTHAI NVARCHAR(50) 
---CHEN DU LIEU COT TRANG THAI
UPDATE PHIEUMUON
SET TRANGTHAI = N'CHUA TRA'
--TRUY VAN CAU 3
SELECT * FROM PHIEUMUON
WHERE TRANGTHAI LIKE N'CHUA%' AND NGAYMUON IS NOT NULL
ORDER BY NGAYMUON

/*6.4 Liệt kê tổng số đầu sách của mỗi loại sách ( gồm mã loại sách, tên loại sách, tổng số
lượng sách mỗi loại).*/
SELECT * FROM THELOAI
SELECT SACH.MATL, TENTL, SUM(soLuongBS) AS TONGSL
FROM THELOAI INNER JOIN SACH
ON THELOAI.MATL = SACH.MATL
GROUP BY SACH.MATL, TENTL

/*6.5 Đếm xem có bao nhiêu lượt sinh viên đã mượn sách.*/
SELECT COUNT(*) AS SOLUOTMUON
FROM PHIEUMUON

/*6.6 Hiển thị tất cả các quyển sách có tiêu đề chứa từ khoá “SQL”.*/
SELECT * FROM SACH
WHERE TIEUDE LIKE N'CON%'

/*6.7 Hiển thị thông tin mượn sách gồm các thông tin: mã sinh viên, tên sinh viên, mã
phiếu mượn, tiêu đề sách, ngày mượn, ngày trả. Sắp xếp thứ tự theo ngày mượn sách.*/
SELECT * FROM SINHVIEN 
SELECT * FROM PHIEUMUON
SELECT SINHVIEN.MASV, SINHVIEN.HOTEN, PHIEUMUON.MAPHIEU, SACH.TIEUDE, PHIEUMUON.NGAYMUON,
GETDATE() AS NGAYTRA
FROM SINHVIEN 
INNER JOIN PHIEUMUON
ON SINHVIEN.MASV = PHIEUMUON.MASV
INNER JOIN CTPHIEUMUON ON PHIEUMUON.MAPHIEU = CTPHIEUMUON.MAPHIEU
INNER JOIN SACH ON SACH.MASACH = CTPHIEUMUON.MASACH
ORDER BY  NGAYMUON

/*6.8 Liệt kê các đầu sách có lượt mượn lớn hơn 20 lần.*/
SELECT MASACH, COUNT(MASACH) AS LUOTMUON
FROM CTPHIEUMUON
GROUP BY MASACH
HAVING COUNT(MASACH) >= 1

/*6.9 Viết câu lệnh cập nhật lại giá tiền của các quyển sách có ngày nhập kho trước năm
2014 giảm 30%.*/
SELECT * FROM SACH
UPDATE SACH
SET GIAtien = GIAtien * 0.7
WHERE YEAR(NGAYnhapkho) < 2000

/*6.10 Viết câu lệnh cập nhật lại trạng thái đã trả sách cho phiếu mượn của sinh viên có mã
sinh viên PD12301 (ví dụ).*/
SELECT * FROM CTPHIEUMUON
UPDATE PHIEUMUON
SET TRANGTHAI = N'CHUA TRA'
WHERE MASV = 'MA01'

/*6.11 Lập danh sách các phiếu mượn quá hạn chưa trả gồm các thông tin: mã phiếu mượn,
tên sinh viên, email, danh sách các sách đã mượn, ngày mượn.*/
SELECT * FROM PHIEUMUON
SELECT COUNT(MAPHIEU) AS QUAHAN
FROM PHIEUMUON
WHERE TRANGTHAI LIKE N'CHUA TRA' AND DAY(NGAYMUON) > 0 AND MONTH(NGAYMUON) > 0

/*6.12 Viết câu lệnh cập nhật lại số lượng bản sao tăng lên 5 đơn vị đối với các đầu sách có
lượt mượn lớn hơn 10*/
UPDATE SACH 
SET soLuongBS = soLuongBS + 50
WHERE MASACH IN (SELECT MASACH FROM CTPHIEUMUON 
GROUP BY MASACH
HAVING COUNT(MASACH) >5
)
SELECT soLuongBS FROM SACH

/*6.13 Viết câu lệnh xoá các phiếu mượn có ngày mượn và ngày trả trước "1/1/2010‟*/
---XOA FK TRUOC PK SAU
DELETE FROM CTPHIEUMUON
WHERE SOLUONG IN (SELECT SOLUONG FROM PHIEUMUON
WHERE NGAYMUON < '1-1-3332')
SELECT * FROM CTPHIEUMUON


